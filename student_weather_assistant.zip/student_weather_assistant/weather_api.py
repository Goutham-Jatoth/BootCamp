import requests

def get_weather(city: str) -> dict:
    """
    Fetch current weather using Open-Meteo API (Free, No API Key needed)
    """
    try:
        # Step 1: Get latitude and longitude of the city
        geo_url = f"https://geocoding-api.open-meteo.com/v1/search?name={city}&count=1&language=en&format=json"
        geo_response = requests.get(geo_url, timeout=10).json()

        if "results" not in geo_response or len(geo_response["results"]) == 0:
            return {"error": f"City '{city}' not found."}

        lat = geo_response["results"][0]["latitude"]
        lon = geo_response["results"][0]["longitude"]
        city_name = geo_response["results"][0]["name"]

        # Step 2: Get current weather
        weather_url = (
            f"https://api.open-meteo.com/v1/forecast?"
            f"latitude={lat}&longitude={lon}"
            f"&current=temperature_2m,relative_humidity_2m,wind_speed_10m,weather_code"
            f"&timezone=auto"
        )
        weather_response = requests.get(weather_url, timeout=10).json()

        current = weather_response.get("current", {})

        weather_data = {
            "city": city_name,
            "temperature": current.get("temperature_2m"),
            "humidity": current.get("relative_humidity_2m"),
            "wind_speed": current.get("wind_speed_10m"),
            "weather_code": current.get("weather_code"),
            "time": current.get("time")
        }

        return weather_data

    except Exception as e:
        return {"error": str(e)}